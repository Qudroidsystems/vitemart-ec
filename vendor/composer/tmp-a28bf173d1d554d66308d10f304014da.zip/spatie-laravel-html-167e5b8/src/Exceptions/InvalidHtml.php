<?php

namespace Spatie\Html\Exceptions;

use Exception;

class InvalidHtml extends Exception
{
}
