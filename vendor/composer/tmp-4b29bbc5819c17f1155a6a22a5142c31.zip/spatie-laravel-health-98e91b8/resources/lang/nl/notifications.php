<?php

return [
    'laravel_health' => 'Laravel Health',

    'check_failed_mail_subject' => 'Enkele van de health checks op :application_name faalden',

    'check_failed_mail_body' => 'De volgende health checks resulteerden in een warning of error:',

    'check_failed_slack_message' => 'Enkele van de health checks op :application_name faalden.',

    'health_results' => 'Health Results',

    'check_results_from' => 'Resultaten van check van ',
];
