<?php

return [
    'laravel_health' => 'Laravel Health',

    'check_failed_mail_subject' => 'Alcuni check sulla salute di :application_name sono falliti',

    'check_failed_mail_body' => 'I seguenti check hanno riportato warning o errori:',

    'check_failed_slack_message' => 'Alcuni check sulla saluta di :application_name sono falliti.',

    'health_results' => 'Risultati check sulla salute',

    'check_results_from' => 'Risultati check di',
];
