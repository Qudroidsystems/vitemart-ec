<?php

return [
    'laravel_health' => 'Laravel Health',

    'check_failed_mail_subject' => 'لقد فشلت بعض عمليات التحقق من السلامة على :application_name',

    'check_failed_mail_body' => 'أبلغت عمليات التحقق التالية عن تحذيرات وأخطاء:',

    'check_failed_slack_message' => 'لقد فشلت بعض عمليات التحقق من السلامة على :application_name.',

    'health_results' => 'نتائج الصحة',

    'check_results_from' => 'التحقق من النتائج من',
];
