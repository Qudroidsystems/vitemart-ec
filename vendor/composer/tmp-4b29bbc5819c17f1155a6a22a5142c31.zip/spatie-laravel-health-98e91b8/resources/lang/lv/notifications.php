<?php

return [
    'laravel_health' => 'Laravel Health',

    'check_failed_mail_subject' => ':application_name pārbaudes laikā tika konstatētas kļūdas',

    'check_failed_mail_body' => 'Konstatētas sekojošas kļūdas un brīdinājumi:',

    'check_failed_slack_message' => ':application_name pārbaudes laikā tika konstatētas kļūdas.',

    'health_results' => 'Pārbaudes rezultāti',

    'check_results_from' => 'Pārbaudes rezultāti',
];
