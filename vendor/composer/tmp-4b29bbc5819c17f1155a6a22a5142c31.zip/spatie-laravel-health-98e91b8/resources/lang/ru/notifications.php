<?php

return [
    'laravel_health' => 'Laravel Health',

    'check_failed_mail_subject' => 'Во время проверки :application_name обнаружены ошибки',

    'check_failed_mail_body' => 'Обнаружены следующие ошибки и предупреждения:',

    'check_failed_slack_message' => 'Во время проверки :application_name обнаружены ошибки.',

    'health_results' => 'Результаты проверки',

    'check_results_from' => 'Посмотреть результаты',
];
