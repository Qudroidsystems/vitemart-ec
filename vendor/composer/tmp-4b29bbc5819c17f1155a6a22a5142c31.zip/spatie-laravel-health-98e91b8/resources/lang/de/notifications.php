<?php

return [
    'laravel_health' => 'Laravel Gesundheit',

    'check_failed_mail_subject' => 'Einige Kontrollen für :application_name sind fehlgeschlagen',

    'check_failed_mail_body' => 'Folgende Kontrollen haben Warnungen und Fehler gemeldet:',

    'check_failed_slack_message' => 'Einige Kontrollen für :application_name sind fehlgeschlagen.',

    'health_results' => 'Gesundheitsergebnisse',

    'check_results_from' => 'Gesundheitsergebnisse von',
];
