<?php

return [
    'laravel_health' => 'سلامت لاراول',

    'check_failed_mail_subject' => 'بررسی برخی موارد امنیتی در برنامه :application_name از نظر سلامت ناموفق بود',

    'check_failed_mail_body' => 'موارد ذکر شده دارای خطا می باشد:',

    'check_failed_slack_message' => 'بررسی برخی موارد امنیتی در برنامه :application_name از نظر سلامت ناموفق بود',

    'health_results' => 'گزارش وضعیت سلامت',

    'check_results_from' => 'نتیجه بررسی:',
];
