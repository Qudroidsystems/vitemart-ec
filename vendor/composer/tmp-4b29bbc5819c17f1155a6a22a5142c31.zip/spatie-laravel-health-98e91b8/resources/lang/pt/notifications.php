<?php

return [
    'laravel_health' => 'Laravel Health',

    'check_failed_mail_subject' => 'Falharam algumas verificações de saúde em :application_name',

    'check_failed_mail_body' => 'As seguintes verificações reportaram avisos e erros:',

    'check_failed_slack_message' => 'Falharam algumas verificações de saúde em :application_name .',

    'health_results' => 'Resultados da saúde',

    'check_results_from' => 'Verificar resultados de',
];
