<?php

return [
    'laravel_health' => 'Laravel Health',

    'check_failed_mail_subject' => 'Algunos de los chequeos en :application_name han fallado',

    'check_failed_mail_body' => 'Las siguientes validaciones reportaron warnings y errors:',

    'check_failed_slack_message' => 'Algunos de los chequeos en :application_name han fallado.',

    'health_results' => 'Resultados del chequeo',

    'check_results_from' => 'Resultados del chequeo de',
];
