<?php

return [
    'laravel_health' => 'Laravel Health',

    'check_failed_mail_subject' => 'Niektoré kontroly stavu :application_name zlyhali',

    'check_failed_mail_body' => 'Nasledovné kontroly hlásených upozornení a chýb:',

    'check_failed_slack_message' => 'Niektoré kontroly stavu :application_name zlyhali.',

    'health_results' => 'Výsledky',

    'check_results_from' => 'Posledná kontrola',
];
