<?php

return [
    'laravel_health' => 'Laravel Sağlık',

    'check_failed_mail_subject' => ':application_name isimli Uygulamada bazı sağlık kontrolleri başarısız oldu',

    'check_failed_mail_body' => 'Aşağıda belirtilen sağlık kontrolleri uyarı veya hata verdi:',

    'check_failed_slack_message' => ':application_name isimli Uygulamada sağlık kontrolleri başarısız oldu.',

    'health_results' => 'Sağlık Durumu Raporu',

    'check_results_from' => 'Kontrol sonuçları:',
];
