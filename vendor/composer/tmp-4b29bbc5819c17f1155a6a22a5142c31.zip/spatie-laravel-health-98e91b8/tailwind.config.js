module.exports = {
    darkMode: "class",
    content: ["./src/**/*.php", "./resources/**/*.php"],
    theme: {
        extend: {},
    },
    plugins: [],
};
