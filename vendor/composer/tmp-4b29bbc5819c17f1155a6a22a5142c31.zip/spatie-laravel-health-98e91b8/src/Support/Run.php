<?php

namespace Spatie\Health\Support;

class Run {}
