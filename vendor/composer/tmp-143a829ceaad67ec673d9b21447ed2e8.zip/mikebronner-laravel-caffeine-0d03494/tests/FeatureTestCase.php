<?php namespace GeneaLabs\LaravelCaffeine\Tests;

use Orchestra\Testbench\BrowserKit\TestCase as BaseTestCase;

abstract class FeatureTestCase extends BaseTestCase
{
    use CreatesApplication;
}
