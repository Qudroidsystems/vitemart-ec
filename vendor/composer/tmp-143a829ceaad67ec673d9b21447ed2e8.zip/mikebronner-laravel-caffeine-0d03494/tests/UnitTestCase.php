<?php namespace GeneaLabs\LaravelCaffeine\Tests;

use Orchestra\Testbench\TestCase as BaseTestCase;

abstract class UnitTestCase extends BaseTestCase
{
    use CreatesApplication;
}
